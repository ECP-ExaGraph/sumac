var searchData=
[
  ['x',['x',['../a00309.html#a9a4f74af87a76a4c3dcb729cb0e68f8d',1,'lemon::dim2::Point']]],
  ['xmap',['XMap',['../a00439.html#a70c36f0d3b618043d829adc868b85072',1,'lemon::dim2::XMap::XMap(M &amp;map)'],['../a00606.html#gae41a8ab860bdbb63080b0e509c487c57',1,'lemon::dim2::XMap::xMap(M &amp;m)'],['../a00606.html#ga089526b0c8613c8167ee758056c79672',1,'lemon::dim2::ConstXMap::xMap()']]],
  ['xmap',['XMap',['../a00439.html',1,'lemon::dim2']]]
];
