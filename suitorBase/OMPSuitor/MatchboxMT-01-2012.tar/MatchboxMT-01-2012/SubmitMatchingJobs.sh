#!/bin/ksh
for d in *.bin; do

done

#export SUNW_MP_PROCBIND="0-127"
# ./wls | tee dat.out.$OMP_NUM_THREADS

