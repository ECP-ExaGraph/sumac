#include <iostream>
//#include <cinttypes>
int main() {
  printf("Size of unsigned int = %ld\n", sizeof(unsigned int));
  printf("Size of long         = %ld\n", sizeof(long));

 return 0;
}
