./configure --prefix=$PWD  --enable-openmp \
 --enable-static
 
