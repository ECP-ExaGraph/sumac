#include "graph_defs.h"
#include "graph_gen.h"

/* TODO */

void gen_lmesh_graph(graph_t* G, char* filename) {

}

void gen_sqmesh_graph(graph_t* G, char* filename) {

}
