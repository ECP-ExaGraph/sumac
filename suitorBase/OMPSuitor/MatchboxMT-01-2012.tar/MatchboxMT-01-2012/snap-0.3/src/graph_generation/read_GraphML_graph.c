#include "graph_defs.h"
#include "graph_gen.h"

void read_GraphML_graph(graph_t* G, char* filename) {

} 
