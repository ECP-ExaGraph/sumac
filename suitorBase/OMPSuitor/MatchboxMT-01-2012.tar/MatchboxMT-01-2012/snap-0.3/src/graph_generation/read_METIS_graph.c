#include "graph_defs.h"
#include "graph_gen.h"

void read_METIS_graph(graph_t* G, char* filename) {

} 
