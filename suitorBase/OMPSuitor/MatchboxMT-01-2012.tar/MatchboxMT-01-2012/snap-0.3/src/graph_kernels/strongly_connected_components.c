#include "graph_defs.h"
#include "graph_kernels.h"

void strongly_connected_components(graph_t* G, attr_id_t* component_num) {



}
