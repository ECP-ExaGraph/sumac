#ifndef _CPUTIME_H
#define _CPUTIME_H

#ifdef __STDC__
double    cputime(void);
#else
double    cputime();
#endif

#endif
