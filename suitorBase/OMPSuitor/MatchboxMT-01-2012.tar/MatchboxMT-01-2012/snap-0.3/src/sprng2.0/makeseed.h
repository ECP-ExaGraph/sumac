#ifndef _MAKESEED_H
#define _MAKESEED_H

#ifdef __STDC__
int make_new_seed(void);
#else
int make_new_seed();
#endif

#endif
